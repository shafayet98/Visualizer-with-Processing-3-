/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pikaboo;

import ddf.minim.*;
import ddf.minim.analysis.*;
import processing.core.PApplet;
import processing.core.PImage;

/**
 *
 * @author Shafayet
 */
public class MySketch extends PApplet {

    Minim minim;
    AudioPlayer player;
    FFT fft;
    
    
    
    String filepath = "A:\\Processing\\Let's see\\sketch_180614a\\one-more.mp3";
    
    public void pikaboo(){
        
        minim = new Minim(this);
        player = minim.loadFile(filepath);
    
    }
    
    
    public void settings() {
        size(600, 400);

    }

    public void setup() {

//        minim = new Minim(this);
//        player = minim.loadFile("A:\\Processing\\Let's see\\sketch_180614a\\one-more.mp3");
        pikaboo();
        fft = new FFT(player.bufferSize(), player.sampleRate());
        player.play();

    }

    @Override
    public void draw() {

            PImage p = get();
            tint(200, 0, 0, 100);
            image(p, -2, -2, 600, 400); //204 204
            stroke(255);

            strokeWeight(2);
            float a = 0;
            float angle = (2*PI) / 200;
            int step = player.bufferSize() / 200;
            for(int i=0; i < player.bufferSize() - step; i+=step) {
              float x = 300 + cos(a) * (40 * player.mix.get(i) + 100);
              float y = 200 + sin(a) * (40 * player.mix.get(i) + 100);
              float x2 = 300 + cos(a + angle) * (40 * player.mix.get(i+step) + 100);
              float y2 = 200 + sin(a + angle) * (40 * player.mix.get(i+step) + 100);
              line(x,y,x2,y2);
              a += angle;
        }
            fft.forward(player.mix);
            noStroke();
            fill(243, 0, 0, 128);
            for(int i = 0; i < 300; i++)
                {
                    float b = fft.getBand(i);
                    float x = random(-b, b) + width/5;
                    float y = i*2;
                    ellipse(x, y, b, b);
                    rect(i*2, height - b, 5, b);
                }

    }

    @Override
    public void stop() {
        player.close();
        minim.stop();
        super.stop();
    }

}
